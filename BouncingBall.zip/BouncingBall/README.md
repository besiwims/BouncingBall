# BouncingBall
This is a Haskell animation project using FreeGLUT.
For more information about FreeGLUT, visit:
http://freeglut.sourceforge.net

## This project is being adapted and converted to CG HP Marathon app: This is 
a small real world application for practicing coding 

